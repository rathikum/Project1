import HomeComponent from './homeContainer';

export default HomeComponent;