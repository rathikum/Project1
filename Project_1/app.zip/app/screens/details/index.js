import DetailComponent from './detailContainer';

export default DetailComponent;