import LoginComponent from './loginContainer';

export default LoginComponent;