import env from 'react-native-config';



const config = {
    api:{
        host:env.baseUrl,
        timeout:2000
    }
};

export default config;