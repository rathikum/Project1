//Import all the actions files created and eport the same to get access accross application.

import * as loginActions from './loginActions';

export {
    loginActions
};