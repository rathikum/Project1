import GLoadingSpinnerHOC from './GLoadingSpinnerHOC';

export {
    GLoadingSpinnerHOC
};
